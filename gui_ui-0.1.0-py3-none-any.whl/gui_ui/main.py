"""
gui_ui — визуальный конструктор Tkinter-интерфейсов.

Запуск:  gui_ui
Зависимости: только стандартная библиотека Python.
"""

from __future__ import annotations

import ast
import json
import re
import subprocess
import sys
import tempfile
import traceback
from dataclasses import dataclass, field, asdict
from typing import Any

import tkinter as tk
from tkinter import ttk, filedialog, messagebox


# ══════════════════════════════════════════════════════════════════
#  МОДЕЛЬ ДАННЫХ
# ══════════════════════════════════════════════════════════════════

@dataclass
class WidgetSpec:
    wid: str
    kind: str
    parent: str = "root"
    text: str = ""
    geometry: dict = field(default_factory=lambda: {"x": 20, "y": 20, "w": 120, "h": 32})
    style: dict = field(default_factory=dict)
    events: dict = field(default_factory=dict)
    extra: dict = field(default_factory=dict)

    def to_json(self) -> dict:
        return asdict(self)

    @classmethod
    def from_json(cls, d: dict) -> "WidgetSpec":
        return cls(**d)


HELPER_CODE = '''

def _call_with_event(fn, event=None):
    """Вызывает fn(event), если она принимает аргумент, иначе fn()."""
    import inspect
    try:
        sig = inspect.signature(fn)
        if len(sig.parameters) >= 1:
            return fn(event)
    except (TypeError, ValueError):
        pass
    return fn()

'''


@dataclass
class Project:
    title: str = "Untitled"
    geometry: str = "800x600"
    imports: list = field(default_factory=list)
    widgets: list = field(default_factory=list)
    functions: dict = field(default_factory=dict)

    def canvas_size(self) -> tuple[int, int]:
        try:
            w, h = self.geometry.lower().split("x")
            return int(w), int(h)
        except Exception:
            return 800, 600

    def to_json(self) -> dict:
        return {
            "title": self.title,
            "geometry": self.geometry,
            "imports": list(self.imports),
            "widgets": [w.to_json() for w in self.widgets],
            "functions": dict(self.functions),
        }

    @classmethod
    def from_json(cls, d: dict) -> "Project":
        p = cls(title=d.get("title", "Untitled"),
                geometry=d.get("geometry", "800x600"),
                imports=list(d.get("imports", [])),
                functions=dict(d.get("functions", {})))
        p.widgets = [WidgetSpec.from_json(w) for w in d.get("widgets", [])]
        return p

    def to_code(self) -> str:
        lines: list[str] = []
        lines.append("from tkinter import *\n")
        lines.append("from tkinter import ttk\n")

        for imp in self.imports:
            imp = imp.strip()
            if not imp:
                continue
            if imp.startswith("import ") or imp.startswith("from "):
                lines.append(imp + "\n")
            else:
                lines.append(f"import {imp}\n")

        has_events = any(w.events for w in self.widgets)
        if has_events:
            lines.append(HELPER_CODE)

        lines.append("\ntk = Tk()\n")
        lines.append(f"tk.geometry('{self.geometry}')\n")
        lines.append(f"tk.title('{self.title}')\n\n")

        for name, body in self.functions.items():
            lines.append(f"def {name}():\n")
            body_lines = (body or "").splitlines() or ["pass"]
            for bl in body_lines:
                lines.append("    " + bl + "\n")
            lines.append("\n")

        ordered = _topo_sort(self.widgets)
        var_map: dict[str, str] = {}
        for spec in ordered:
            var = spec.wid
            parent_var = "tk" if spec.parent == "root" else var_map.get(spec.parent, "tk")
            var_map[spec.wid] = var

            args = _format_widget_args(spec)
            lines.append(f"{var} = {spec.kind}({parent_var}{args})\n")

            for ev, fn in spec.events.items():
                if not fn:
                    continue
                if ev == "command":
                    lines.append(
                        f"{var}.config(command=lambda: _call_with_event({fn}))\n"
                    )
                else:
                    lines.append(
                        f"{var}.bind('{ev}', lambda e: _call_with_event({fn}, e))\n"
                    )

            g = spec.geometry
            lines.append(
                f"{var}.place(x={g.get('x', 0)}, y={g.get('y', 0)}, "
                f"width={g.get('w', 100)}, height={g.get('h', 30)})\n\n"
            )

        lines.append("\ntk.mainloop()\n")
        return "".join(lines)


def _format_widget_args(spec: WidgetSpec) -> str:
    parts: list[str] = []
    if spec.text and spec.kind in {"Button", "Label", "Checkbutton",
                                    "Radiobutton", "LabelFrame"}:
        parts.append(f"text={_q(spec.text)}")
    for k, v in spec.style.items():
        if v in (None, ""):
            continue
        if isinstance(v, (int, float)):
            parts.append(f"{k}={v}")
        elif isinstance(v, str):
            try:
                float(v)
                parts.append(f"{k}={v}")
            except ValueError:
                parts.append(f"{k}={_q(v)}")
        else:
            parts.append(f"{k}={v!r}")
    return (", " + ", ".join(parts)) if parts else ""


def _q(s: str) -> str:
    s = str(s).replace("\\", "\\\\").replace("'", "\\'")
    return f"'{s}'"


def _topo_sort(widgets: list[WidgetSpec]) -> list[WidgetSpec]:
    by_id = {w.wid: w for w in widgets}
    result: list[WidgetSpec] = []
    done: set[str] = set()

    def visit(w: WidgetSpec):
        if w.wid in done:
            return
        done.add(w.wid)
        if w.parent != "root" and w.parent in by_id:
            visit(by_id[w.parent])
        result.append(w)

    for w in widgets:
        visit(w)
    return result


# ══════════════════════════════════════════════════════════════════
#  AST-ИМПОРТЕР
# ══════════════════════════════════════════════════════════════════

WIDGET_CLASSES = {
    "Button", "Label", "Entry", "Text", "Frame", "LabelFrame",
    "Treeview", "Combobox", "Canvas", "Checkbutton", "Radiobutton",
    "Listbox", "Scale", "Spinbox", "Menu", "Notebook",
}


def parse_tkinter_source(source: str) -> Project:
    proj = Project()
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return proj

    for node in tree.body:
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name not in ("tkinter", "tkinter.ttk", "inspect"):
                    proj.imports.append(a.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module and node.module.startswith("tkinter"):
                continue
            if node.module == "inspect":
                continue
            names = ", ".join(a.name for a in node.names)
            proj.imports.append(f"from {node.module} import {names}")

    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            if node.func.attr == "geometry" and node.args:
                try:
                    proj.geometry = ast.literal_eval(node.args[0])
                except Exception:
                    pass
            if node.func.attr == "title" and node.args:
                try:
                    proj.title = ast.literal_eval(node.args[0])
                except Exception:
                    pass

    var_to_spec: dict[str, WidgetSpec] = {}
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        call = node.value
        if not (isinstance(call, ast.Call)
                and isinstance(call.func, ast.Name)
                and call.func.id in WIDGET_CLASSES):
            continue
        try:
            var = node.targets[0].id
        except Exception:
            continue

        parent = "root"
        if call.args:
            arg0 = call.args[0]
            if isinstance(arg0, ast.Name) and arg0.id in var_to_spec:
                parent = var_to_spec[arg0.id].wid

        style: dict = {}
        text = ""
        for kw in call.keywords:
            if kw.arg is None:
                continue
            try:
                val = ast.literal_eval(kw.value)
            except Exception:
                val = "<expr>"
            if kw.arg == "text":
                text = str(val)
            else:
                style[kw.arg] = val

        spec = WidgetSpec(wid=var, kind=call.func.id,
                          parent=parent, text=text, style=style)
        var_to_spec[var] = spec
        proj.widgets.append(spec)

    for node in ast.walk(tree):
        if (isinstance(node, ast.Call)
                and isinstance(node.func, ast.Attribute)
                and node.func.attr in {"place", "pack", "grid"}
                and isinstance(node.func.value, ast.Name)):
            var = node.func.value.id
            if var not in var_to_spec:
                continue
            spec = var_to_spec[var]
            for kw in node.keywords:
                try:
                    val = ast.literal_eval(kw.value)
                except Exception:
                    continue
                if kw.arg == "x": spec.geometry["x"] = val
                elif kw.arg == "y": spec.geometry["y"] = val
                elif kw.arg == "width": spec.geometry["w"] = val
                elif kw.arg == "height": spec.geometry["h"] = val

    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            if node.name == "_call_with_event":
                continue
            src_lines = source.splitlines()[node.lineno - 1: node.end_lineno]
            body = []
            for i, ln in enumerate(src_lines):
                if i == 0:
                    continue
                body.append(ln[4:] if ln.startswith("    ") else ln)
            proj.functions[node.name] = "\n".join(body)

    return proj


# ══════════════════════════════════════════════════════════════════
#  РЕДАКТОР КОДА С АВТОДОПОЛНЕНИЕМ
# ══════════════════════════════════════════════════════════════════

PY_KEYWORDS = {
    "def", "class", "return", "if", "elif", "else", "for", "while", "in",
    "import", "from", "as", "try", "except", "finally", "with", "lambda",
    "None", "True", "False", "and", "or", "not", "pass", "break",
    "continue", "global", "nonlocal", "yield", "raise", "assert", "del",
    "is", "async", "await",
}


# ★ Словарь автодополнения: имя -> (нужны_ли_скобки, отображаемая_подсказка)
COMPLETION_WORDS: dict[str, tuple[bool, str]] = {
    "print":      (True, "print(value, ...)"),
    "len":        (True, "len(obj)"),
    "range":      (True, "range(start, stop[, step])"),
    "int":        (True, "int(x)"),
    "str":        (True, "str(x)"),
    "float":      (True, "float(x)"),
    "bool":       (True, "bool(x)"),
    "list":       (True, "list(iterable)"),
    "dict":       (True, "dict()"),
    "set":        (True, "set(iterable)"),
    "tuple":      (True, "tuple(iterable)"),
    "input":      (True, "input(prompt)"),
    "open":       (True, "open(file, mode)"),
    "sum":        (True, "sum(iterable)"),
    "min":        (True, "min(iterable)"),
    "max":        (True, "max(iterable)"),
    "abs":        (True, "abs(x)"),
    "type":       (True, "type(obj)"),
    "isinstance": (True, "isinstance(obj, cls)"),
    "enumerate":  (True, "enumerate(iterable)"),
    "zip":        (True, "zip(*iterables)"),
    "map":        (True, "map(fn, iterable)"),
    "filter":     (True, "filter(fn, iterable)"),
    "sorted":     (True, "sorted(iterable)"),
    "reversed":   (True, "reversed(seq)"),
    "repr":       (True, "repr(obj)"),
    "format":     (True, "format(value, fmt)"),
    "hasattr":    (True, "hasattr(obj, name)"),
    "getattr":    (True, "getattr(obj, name)"),
    "setattr":    (True, "setattr(obj, name, value)"),
    "dir":        (True, "dir(obj)"),
    "id":         (True, "id(obj)"),
    "help":       (True, "help(obj)"),
    "exit":       (True, "exit()"),
    "quit":       (True, "quit()"),
    "ValueError": (True, "ValueError(...)"),
    "TypeError":  (True, "TypeError(...)"),
    "Exception":  (True, "Exception(...)"),
    "self":       (False, ""),
    "True":       (False, ""),
    "False":      (False, ""),
    "None":       (False, ""),
}


class CodeEditor(tk.Frame):
    def __init__(self, master, extra_words_provider=None, **kw):
        super().__init__(master, **kw)
        self.text = tk.Text(
            self, wrap="none", undo=True,
            font=("Consolas", 11), tabs=("1c"),
            bg="#1e1e1e", fg="#d4d4d4",
            insertbackground="white",
        )
        ysb = ttk.Scrollbar(self, orient="vertical", command=self.text.yview)
        xsb = ttk.Scrollbar(self, orient="horizontal", command=self.text.xview)
        self.text.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)

        self.text.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.extra_words_provider = extra_words_provider

        self._configure_tags()

        # ★ состояние автодополнения
        self._ac_after_id = None
        self._popup = None
        self._popup_lb = None
        self._popup_candidates = None

        # обычные бинды
        self.text.bind("<KeyRelease>", self._on_key)
        self.text.bind("<Return>", self._commit_on_enter)
        self.text.bind("<Tab>", self._commit_on_tab)
        self.text.bind("<Escape>", self._escape_popup)
        self.text.bind("<Up>", self._nav_up)
        self.text.bind("<Down>", self._nav_down)
        self.text.bind("<Control-space>", self._force_autocomplete)
        # клик мышью вне попапа закрывает его
        self.text.bind("<Button-1>", self._on_text_click)

    # ---------- подсветка ----------
    def _configure_tags(self):
        t = self.text
        t.tag_configure("kw",  foreground="#569cd6", font=("Consolas", 11, "bold"))
        t.tag_configure("str", foreground="#ce9178")
        t.tag_configure("com", foreground="#6a9955", font=("Consolas", 11, "italic"))
        t.tag_configure("num", foreground="#b5cea8")
        t.tag_configure("fn",  foreground="#dcdcaa")

    def _highlight(self):
        src = self.text.get("1.0", "end-1c")
        for tag in ("kw", "str", "com", "num", "fn"):
            self.text.tag_remove(tag, "1.0", "end")
        for m in re.finditer(r"#[^\n]*", src):
            self._apply("com", m.start(), m.end())
        for m in re.finditer(r"('[^'\n]*'|\"[^\"\n]*\")", src):
            self._apply("str", m.start(), m.end())
        for m in re.finditer(r"\b(\w+)\b", src):
            w = m.group(1)
            if w in PY_KEYWORDS:
                self._apply("kw", m.start(), m.end())
            elif w.isdigit():
                self._apply("num", m.start(), m.end())
        for m in re.finditer(r"\b(\w+)\s*\(", src):
            self._apply("fn", m.start(1), m.end(1))

    def _apply(self, tag, start, end):
        self.text.tag_add(tag, f"1.0 + {start} chars", f"1.0 + {end} chars")

    # ---------- клавиши ----------
    def _on_key(self, event=None):
        self._highlight()
        # ★ при вводе буквы/цифры/подчёркивания — планируем автодополнение
        if event and event.char and (event.char.isalnum() or event.char == "_"):
            self._schedule_autocomplete()
        elif event and event.keysym in ("BackSpace", "Delete"):
            self._schedule_autocomplete()

    def _auto_indent(self):
        line = self.text.get("insert linestart", "insert")
        indent = re.match(r"\s*", line).group(0)
        extra = "    " if line.rstrip().endswith(":") else ""
        self.text.insert("insert", "\n" + indent + extra)
        self._highlight()

    def _commit_on_enter(self, event):
        if self._popup_lb is not None:
            self._commit_selection()
            return "break"
        self._auto_indent()
        return "break"

    def _commit_on_tab(self, event):
        if self._popup_lb is not None:
            self._commit_selection()
            return "break"
        self.text.insert("insert", "    ")
        return "break"

    def _escape_popup(self, event):
        if self._popup_lb is not None:
            self._close_popup()
            return "break"
        return None

    def _nav_up(self, event):
        if self._popup_lb is not None:
            self._popup_move(-1)
            return "break"
        return None

    def _nav_down(self, event):
        if self._popup_lb is not None:
            self._popup_move(1)
            return "break"
        return None

    def _on_text_click(self, event=None):
        self._close_popup()

    def _force_autocomplete(self, event=None):
        self._try_autocomplete(force=True)
        return "break"

    # ---------- автодополнение ----------
    def _schedule_autocomplete(self):
        if self._ac_after_id:
            try:
                self.after_cancel(self._ac_after_id)
            except Exception:
                pass
        self._ac_after_id = self.after(120, self._try_autocomplete)

    def _current_prefix(self) -> str:
        idx = self.text.index("insert")
        line = self.text.get(f"{idx} linestart", idx)
        m = re.search(r"[A-Za-z_][A-Za-z0-9_]*$", line)
        return m.group(0) if m else ""

    def _try_autocomplete(self, force: bool = False):
        self._ac_after_id = None
        prefix = self._current_prefix()
        if not prefix and not force:
            self._close_popup()
            return
        candidates = self._candidates(prefix)
        if not candidates:
            self._close_popup()
            return
        self._show_popup(candidates, prefix)

    def _candidates(self, prefix: str) -> list[tuple[str, str, bool]]:
        words: dict[str, tuple[bool, str]] = {}
        # ключевые слова
        for kw in PY_KEYWORDS:
            words[kw] = (False, "")
        # встроенные
        for k, v in COMPLETION_WORDS.items():
            words[k] = v
        # функции проекта
        if self.extra_words_provider:
            try:
                for name in self.extra_words_provider() or []:
                    words.setdefault(name, (True, f"{name}()"))
            except Exception:
                pass

        low = prefix.lower()
        result: list[tuple[str, str, bool]] = []
        for name in sorted(words):
            if not prefix or name.lower().startswith(low):
                need_paren, hint = words[name]
                result.append((name, hint, need_paren))

        # приоритет: точное начало префикса → короткие → алфавит
        result.sort(key=lambda x: (
            0 if x[0].startswith(prefix) else 1,
            len(x[0]), x[0]
        ))
        return result[:40]

    def _show_popup(self, candidates, prefix: str):
        self._close_popup()

        popup = tk.Toplevel(self.text)
        popup.wm_overrideredirect(True)
        try:
            popup.attributes("-topmost", True)
        except Exception:
            pass
        try:
            x, y, _, h = self.text.bbox("insert")
            if x is None or y is None:
                x, y, h = 0, 0, 16
        except Exception:
            x, y, h = 0, 0, 16
        popup.wm_geometry(
            f"+{self.text.winfo_rootx() + x}+{self.text.winfo_rooty() + y + h}"
        )

        frame = tk.Frame(popup, bg="#333333", borderwidth=1, relief="solid")
        frame.pack()

        lb = tk.Listbox(
            frame, height=min(10, len(candidates)), width=52,
            bg="#252526", fg="#d4d4d4",
            selectbackground="#094771", selectforeground="#ffffff",
            font=("Consolas", 10), activestyle="none",
            highlightthickness=0, borderwidth=0,
        )
        for name, hint, _ in candidates:
            if hint:
                lb.insert("end", f" {name:<18} {hint}")
            else:
                lb.insert("end", f" {name}")
        lb.pack(side="left", fill="both", expand=True)
        sb = tk.Scrollbar(frame, orient="vertical", command=lb.yview)
        sb.pack(side="right", fill="y")
        lb.configure(yscrollcommand=sb.set)
        if lb.size() > 0:
            lb.selection_set(0)
            lb.activate(0)

        # ★ делаем невладеющим фокус, чтобы не перехватывать ввод
        try:
            popup.attributes("-disabled", True)
        except Exception:
            pass

        lb.bind("<Double-Button-1>", lambda e: self._commit_selection())
        lb.bind("<Return>",          lambda e: self._commit_selection())

        self._popup = popup
        self._popup_lb = lb
        self._popup_candidates = candidates

    def _popup_move(self, delta: int):
        lb = self._popup_lb
        if lb is None:
            return
        sel = lb.curselection()
        idx = (sel[0] if sel else 0) + delta
        idx = max(0, min(lb.size() - 1, idx))
        lb.selection_clear(0, "end")
        lb.selection_set(idx)
        lb.activate(idx)
        lb.see(idx)

    def _commit_selection(self):
        lb = self._popup_lb
        cands = self._popup_candidates
        if lb is None or not cands:
            return
        sel = lb.curselection()
        if not sel:
            return
        name, hint, need_paren = cands[sel[0]]

        prefix = self._current_prefix()
        if prefix:
            self.text.delete(f"insert - {len(prefix)} chars", "insert")

        if need_paren:
            self.text.insert("insert", f"{name}()")
            # курсор между скобок
            self.text.mark_set("insert", "insert - 1 char")
        else:
            self.text.insert("insert", name)

        self._close_popup()
        self._highlight()

    def _close_popup(self):
        popup = self._popup
        if popup is not None:
            try:
                popup.destroy()
            except Exception:
                pass
        self._popup = None
        self._popup_lb = None
        self._popup_candidates = None

    # ---------- публичное API ----------
    def get_code(self):
        return self.text.get("1.0", "end-1c")

    def set_code(self, code):
        if self.get_code() == code:
            return
        self._close_popup()
        self.text.delete("1.0", "end")
        self.text.insert("1.0", code)
        self._highlight()


# ══════════════════════════════════════════════════════════════════
#  ХОЛСТ ДИЗАЙНА
# ══════════════════════════════════════════════════════════════════

class DesignCanvas(tk.Frame):
    PADDING = 40
    RULER = 20
    DRAG_THRESHOLD = 3

    def __init__(self, master, project: Project, on_select, on_change):
        super().__init__(master, bg="#2b2b2b")
        self.project = project
        self.on_select = on_select
        self.on_change = on_change

        self.scale = 1.0
        self.snap = False
        self.grid_step = 10

        top = ttk.Frame(self)
        top.pack(side="top", fill="x")
        ttk.Label(top, text="Размер проекта:").pack(side="left", padx=6, pady=4)
        self.size_var = tk.StringVar()
        ent = ttk.Entry(top, textvariable=self.size_var, width=10)
        ent.pack(side="left")
        ent.bind("<Return>", self._apply_size)
        ttk.Button(top, text="Применить", command=self._apply_size).pack(side="left", padx=4)

        ttk.Label(top, text="   Масштаб:").pack(side="left", padx=(20, 0))
        self.scale_lbl = ttk.Label(top, text="100%")
        self.scale_lbl.pack(side="left")
        ttk.Button(top, text="−", width=3,
                   command=lambda: self.set_scale(self.scale / 1.2)).pack(side="left", padx=2)
        ttk.Button(top, text="+", width=3,
                   command=lambda: self.set_scale(self.scale * 1.2)).pack(side="left", padx=2)
        ttk.Button(top, text="1:1",
                   command=lambda: self.set_scale(1.0)).pack(side="left")

        self.snap_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(top, text="Snap 10px", variable=self.snap_var,
                        command=self._toggle_snap).pack(side="left", padx=12)

        body = ttk.Frame(self)
        body.pack(fill="both", expand=True)

        self.hruler = tk.Canvas(body, height=self.RULER, bg="#3a3a3a",
                                 highlightthickness=0)
        self.hruler.grid(row=0, column=1, sticky="ew")

        self.vruler = tk.Canvas(body, width=self.RULER, bg="#3a3a3a",
                                 highlightthickness=0)
        self.vruler.grid(row=1, column=0, sticky="ns")

        self.canvas = tk.Canvas(body, bg="#555555",
                                highlightthickness=0, bd=0)
        self.canvas.grid(row=1, column=1, sticky="nsew")

        self.vsb = ttk.Scrollbar(body, orient="vertical", command=self.canvas.yview)
        self.vsb.grid(row=1, column=2, sticky="ns")
        self.hsb = ttk.Scrollbar(body, orient="horizontal", command=self.canvas.xview)
        self.hsb.grid(row=2, column=1, sticky="ew")
        self.canvas.configure(yscrollcommand=self.vsb.set, xscrollcommand=self.hsb.set)

        body.rowconfigure(1, weight=1)
        body.columnconfigure(1, weight=1)

        self.stage = tk.Frame(self.canvas, bg="white")
        self.stage_id = self.canvas.create_window(
            self.PADDING, self.PADDING, anchor="nw", window=self.stage)

        self.live: dict[str, tk.Widget] = {}
        self.selected: WidgetSpec | None = None
        self._drag_data = {
            "wid": None, "moved": False,
            "off_x": 0, "off_y": 0,
            "start_lx": 0, "start_ly": 0,
        }

        self._grid_items: list[int] = []
        self._draw_grid_and_rulers()

        self.canvas.bind("<Button-1>", self._clear_selection)
        self.canvas.bind("<Configure>", lambda e: self._draw_grid_and_rulers())
        self.canvas.bind("<Control-MouseWheel>", self._on_ctrl_wheel)
        self.bind_all("<Control-plus>",  lambda e: self.set_scale(self.scale * 1.2))
        self.bind_all("<Control-equal>", lambda e: self.set_scale(self.scale * 1.2))
        self.bind_all("<Control-minus>", lambda e: self.set_scale(self.scale / 1.2))

        self._sync_size_entry()
        self._resize_stage()

    # ---------- размеры / зум ----------
    def _sync_size_entry(self):
        self.size_var.set(self.project.geometry)

    def _apply_size(self, event=None):
        val = self.size_var.get().strip()
        if "x" not in val.lower():
            messagebox.showerror("Ошибка", "Формат: ШИРИНАxВЫСОТА, напр. 800x600")
            return
        self.project.geometry = val
        self._resize_stage()

    def _resize_stage(self):
        w, h = self.project.canvas_size()
        w2 = max(50, int(w * self.scale))
        h2 = max(50, int(h * self.scale))
        self.stage.configure(width=w2, height=h2)
        self.stage.pack_propagate(False)
        self.stage.grid_propagate(False)
        self.canvas.configure(
            scrollregion=(0, 0, w2 + self.PADDING * 2, h2 + self.PADDING * 2))
        self._draw_grid_and_rulers()
        self.scale_lbl.config(text=f"{int(self.scale*100)}%")

    def set_scale(self, new_scale):
        new_scale = max(0.25, min(3.0, new_scale))
        if abs(new_scale - self.scale) < 1e-6:
            return
        self.scale = new_scale
        self._resize_stage()
        self.render_all()
        self._draw_grid_and_rulers()

    def _on_ctrl_wheel(self, event):
        factor = 1.1 if event.delta > 0 else 1 / 1.1
        self.set_scale(self.scale * factor)

    def _toggle_snap(self):
        self.snap = self.snap_var.get()

    # ---------- сетка / линейки ----------
    def _draw_grid_and_rulers(self):
        for item in self._grid_items:
            self.canvas.delete(item)
        self._grid_items.clear()

        w, h = self.project.canvas_size()
        sw, sh = int(w * self.scale), int(h * self.scale)
        step = max(4, int(self.grid_step * self.scale))

        for x in range(0, sw + 1, step):
            item = self.canvas.create_line(
                self.PADDING + x, self.PADDING,
                self.PADDING + x, self.PADDING + sh,
                fill="#dddddd", tags="grid")
            self._grid_items.append(item)
        for y in range(0, sh + 1, step):
            item = self.canvas.create_line(
                self.PADDING, self.PADDING + y,
                self.PADDING + sw, self.PADDING + y,
                fill="#dddddd", tags="grid")
            self._grid_items.append(item)

        border = self.canvas.create_rectangle(
            self.PADDING, self.PADDING,
            self.PADDING + sw, self.PADDING + sh,
            outline="#ff6600", width=2, tags="grid")
        self._grid_items.append(border)

        self._draw_rulers(sw, sh, step)

    def _draw_rulers(self, sw, sh, step):
        self.hruler.delete("all")
        self.vruler.delete("all")

        for x in range(0, sw + 1, step):
            px = self.PADDING + x
            self.hruler.create_line(px, self.RULER - 4, px, self.RULER,
                                    fill="#888888")
            if x % (step * 5) == 0:
                self.hruler.create_text(px + 2, 4, anchor="nw",
                                        text=str(int(x / self.scale)),
                                        fill="#cccccc", font=("Arial", 7))

        for y in range(0, sh + 1, step):
            py = self.PADDING + y
            self.vruler.create_line(self.RULER - 4, py, self.RULER, py,
                                    fill="#888888")
            if y % (step * 5) == 0:
                self.vruler.create_text(2, py + 2, anchor="nw",
                                        text=str(int(y / self.scale)),
                                        fill="#cccccc", font=("Arial", 7))

    # ---------- рендер ----------
    def _clear_selection(self, event=None):
        if self.selected:
            w = self.live.get(self.selected.wid)
            if w:
                try:
                    w.configure(highlightthickness=0)
                except tk.TclError:
                    pass
        self.selected = None
        self.on_select(None)

    def render_all(self):
        for w in self.live.values():
            try:
                w.destroy()
            except Exception:
                pass
        self.live.clear()

        for spec in _topo_sort(self.project.widgets):
            self._render_one(spec)

    def _render_one(self, spec: WidgetSpec):
        parent_widget: tk.Widget = self.stage
        if spec.parent != "root" and spec.parent in self.live:
            parent_widget = self.live[spec.parent]

        cls = getattr(tk, spec.kind, None) or getattr(ttk, spec.kind, None)
        if cls is None:
            return

        kw: dict[str, Any] = {}
        if spec.text and spec.kind in {"Button", "Label", "Checkbutton",
                                        "Radiobutton", "LabelFrame"}:
            kw["text"] = spec.text
        for k, v in spec.style.items():
            if v in ("", None):
                continue
            try:
                kw[k] = v
            except Exception:
                pass

        try:
            widget = cls(parent_widget, **kw)
        except tk.TclError:
            widget = cls(parent_widget)
            if spec.text:
                try:
                    widget.configure(text=spec.text)
                except Exception:
                    pass

        g = spec.geometry
        x = int(g["x"] * self.scale)
        y = int(g["y"] * self.scale)
        w_ = max(1, int(g["w"] * self.scale))
        h_ = max(1, int(g["h"] * self.scale))
        widget.place(x=x, y=y, width=w_, height=h_)

        widget.bind("<Button-1>",
                    lambda e, s=spec, w=widget: self._on_widget_click(e, s, w))
        widget.bind("<B1-Motion>", self._on_drag)
        widget.bind("<ButtonRelease-1>", self._on_release)

        self.live[spec.wid] = widget

    def recreate_widget(self, spec: WidgetSpec):
        old = self.live.pop(spec.wid, None)
        if old is not None:
            try:
                old.destroy()
            except Exception:
                pass
        self._render_one(spec)
        if self.selected and self.selected.wid == spec.wid:
            w = self.live.get(spec.wid)
            if w:
                try:
                    w.configure(highlightthickness=2,
                                highlightbackground="#ff6600",
                                highlightcolor="#ff6600")
                except tk.TclError:
                    pass

    # ---------- drag ----------
    def _cursor_in_stage(self, event) -> tuple[float, float]:
        cx_canvas = event.x_root - self.canvas.winfo_rootx()
        cy_canvas = event.y_root - self.canvas.winfo_rooty()
        cx_canvas = self.canvas.canvasx(cx_canvas)
        cy_canvas = self.canvas.canvasy(cy_canvas)
        lx = (cx_canvas - self.PADDING) / self.scale
        ly = (cy_canvas - self.PADDING) / self.scale
        return lx, ly

    def _on_widget_click(self, event, spec: WidgetSpec, widget: tk.Widget):
        if self.selected and self.selected.wid != spec.wid:
            old = self.live.get(self.selected.wid)
            if old:
                try:
                    old.configure(highlightthickness=0)
                except tk.TclError:
                    pass
        self.selected = spec
        try:
            widget.configure(highlightthickness=2,
                             highlightbackground="#ff6600",
                             highlightcolor="#ff6600")
        except tk.TclError:
            pass

        lx, ly = self._cursor_in_stage(event)
        self._drag_data["start_lx"] = lx
        self._drag_data["start_ly"] = ly
        self._drag_data["off_x"] = lx - spec.geometry["x"]
        self._drag_data["off_y"] = ly - spec.geometry["y"]
        self._drag_data["wid"] = spec.wid
        self._drag_data["moved"] = False

        self.on_select(spec)

    def _on_drag(self, event):
        wid = self._drag_data.get("wid")
        if not wid:
            return
        spec = next((w for w in self.project.widgets if w.wid == wid), None)
        if not spec:
            return

        lx, ly = self._cursor_in_stage(event)

        if not self._drag_data["moved"]:
            ddx = lx - self._drag_data["start_lx"]
            ddy = ly - self._drag_data["start_ly"]
            if abs(ddx) < self.DRAG_THRESHOLD and abs(ddy) < self.DRAG_THRESHOLD:
                return
            self._drag_data["off_x"] = lx - spec.geometry["x"]
            self._drag_data["off_y"] = ly - spec.geometry["y"]
            self._drag_data["moved"] = True

        nx = lx - self._drag_data["off_x"]
        ny = ly - self._drag_data["off_y"]

        if self.snap:
            nx = round(nx / self.grid_step) * self.grid_step
            ny = round(ny / self.grid_step) * self.grid_step

        new_x = int(round(max(0, nx)))
        new_y = int(round(max(0, ny)))
        if spec.geometry["x"] == new_x and spec.geometry["y"] == new_y:
            return

        spec.geometry["x"] = new_x
        spec.geometry["y"] = new_y

        w = self.live.get(wid)
        if w:
            w.place(x=int(spec.geometry["x"] * self.scale),
                    y=int(spec.geometry["y"] * self.scale))

        if self.selected and self.selected.wid == wid:
            self.on_change(spec, kind="geometry")

    def _on_release(self, event):
        wid = self._drag_data.get("wid")
        moved = self._drag_data.get("moved")
        self._drag_data["wid"] = None
        self._drag_data["moved"] = False
        if wid and moved:
            spec = next((w for w in self.project.widgets if w.wid == wid), None)
            if spec:
                self.on_change(spec, kind="geometry")


# ══════════════════════════════════════════════════════════════════
#  ИНСПЕКТОР
# ══════════════════════════════════════════════════════════════════

BASE_PROPS = ["text", "bg", "fg", "font", "padx", "pady",
              "width", "height", "state", "relief"]

ALL_PROPS = BASE_PROPS + [
    "anchor", "justify", "wraplength", "cursor", "bd",
    "highlightbackground", "highlightthickness", "takefocus",
    "disabledforeground", "activebackground", "activeforeground",
]

EVENT_TYPES = ["command", "<Button-1>", "<Double-Button-1>",
               "<Button-3>", "<Enter>", "<Leave>", "<KeyRelease>"]


class Inspector(ttk.Notebook):
    def __init__(self, master):
        super().__init__(master)
        self.props_frame = ttk.Frame(self)
        self.code_frame = ttk.Frame(self)
        self.add(self.props_frame, text="Свойства")
        self.add(self.code_frame, text="Код")

        self.current: WidgetSpec | None = None
        self.on_change = None
        self.function_names_provider = lambda: []

        self.props_vars: dict[str, tk.StringVar] = {}
        self.entries: dict[str, ttk.Entry] = {}

        self._loading = False

        self._build_props()
        self._build_code()

    def _build_props(self):
        canvas = tk.Canvas(self.props_frame, highlightthickness=0)
        sb = ttk.Scrollbar(self.props_frame, orient="vertical",
                           command=canvas.yview)
        inner = ttk.Frame(canvas)
        inner.bind("<Configure>",
                   lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.create_window((0, 0), window=inner, anchor="nw")
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")
        self._inner = inner

        f = inner
        f.columnconfigure(1, weight=1)

        row = 0
        ttk.Label(f, text="Widget ID:").grid(row=row, column=0, sticky="w", padx=4, pady=2)
        self.id_lbl = ttk.Label(f, text="—", foreground="#0055aa")
        self.id_lbl.grid(row=row, column=1, sticky="w", padx=4)
        row += 1

        ttk.Separator(f, orient="horizontal").grid(row=row, columnspan=2, sticky="ew", pady=4)
        row += 1
        ttk.Label(f, text="Геометрия (px)",
                  font=("", 10, "bold")).grid(row=row, columnspan=2, sticky="w", padx=4)
        row += 1

        self.geom_vars: dict[str, tk.StringVar] = {}
        for key in ("x", "y", "w", "h"):
            lbl = ttk.Label(f, text=key)
            var = tk.StringVar()
            ent = ttk.Entry(f, textvariable=var, width=10)
            var.trace_add("write", lambda *_: self._push_geometry())
            lbl.grid(row=row, column=0, sticky="w", padx=4)
            ent.grid(row=row, column=1, sticky="ew", padx=4)
            self.geom_vars[key] = var
            self.entries["__geom_" + key] = ent
            row += 1

        ttk.Separator(f, orient="horizontal").grid(row=row, columnspan=2, sticky="ew", pady=4)
        row += 1
        ttk.Label(f, text="Стиль", font=("", 10, "bold")).grid(row=row, columnspan=2, sticky="w", padx=4)
        row += 1

        for p in BASE_PROPS:
            lbl = ttk.Label(f, text=p)
            var = tk.StringVar()
            ent = ttk.Entry(f, textvariable=var)
            var.trace_add("write", lambda *_: self._push_style())
            lbl.grid(row=row, column=0, sticky="w", padx=4, pady=1)
            ent.grid(row=row, column=1, sticky="ew", padx=4, pady=1)
            self.props_vars[p] = var
            self.entries[p] = ent
            row += 1

        ttk.Label(f, text="Добавить свойство:").grid(row=row, column=0, sticky="w", padx=4, pady=(8, 2))
        row += 1
        self.extra_cb = ttk.Combobox(f, values=ALL_PROPS, state="readonly")
        self.extra_cb.grid(row=row, columnspan=2, sticky="ew", padx=4)
        self.extra_cb.bind("<<ComboboxSelected>>", self._add_extra_prop)
        row += 1

        ttk.Separator(f, orient="horizontal").grid(row=row, columnspan=2, sticky="ew", pady=6)
        row += 1
        ttk.Label(f, text="События", font=("", 10, "bold")).grid(row=row, columnspan=2, sticky="w", padx=4)
        row += 1
        self.event_vars: dict[str, tk.StringVar] = {}
        self.event_cbs: dict[str, ttk.Combobox] = {}
        for ev in EVENT_TYPES:
            lbl = ttk.Label(f, text=ev)
            var = tk.StringVar()
            cb = ttk.Combobox(f, textvariable=var, state="readonly")
            cb.bind("<<ComboboxSelected>>", lambda e: self._push_events())
            lbl.grid(row=row, column=0, sticky="w", padx=4, pady=1)
            cb.grid(row=row, column=1, sticky="ew", padx=4, pady=1)
            self.event_vars[ev] = var
            self.event_cbs[ev] = cb
            row += 1

        btns = ttk.Frame(f)
        btns.grid(row=row, columnspan=2, sticky="ew", pady=8)
        ttk.Button(btns, text="Удалить", command=self._delete_current).pack(side="left", padx=4)
        ttk.Button(btns, text="На передний план",
                   command=self._bring_front).pack(side="right", padx=4)

    def _build_code(self):
        f = self.code_frame
        f.rowconfigure(0, weight=1)
        f.columnconfigure(0, weight=1)
        self.code_editor = CodeEditor(f)
        self.code_editor.grid(row=0, column=0, sticky="nsew")
        ttk.Button(f, text="Применить изменения из кода",
                   command=self._apply_code).grid(row=1, column=0, pady=4)

    # ---------- загрузка ----------
    def load(self, spec: WidgetSpec | None):
        self._loading = True
        try:
            self.current = spec
            if spec is None:
                self.id_lbl.config(text="—")
                for v in self.props_vars.values():
                    v.set("")
                for v in self.geom_vars.values():
                    v.set("")
                for v in self.event_vars.values():
                    v.set("")
                self.code_editor.set_code("")
                return

            self.id_lbl.config(text=spec.wid)
            for k, v in self.geom_vars.items():
                v.set(str(spec.geometry.get(k, "")))

            for p in BASE_PROPS:
                if p == "text":
                    self.props_vars[p].set(spec.text)
                else:
                    self.props_vars[p].set(str(spec.style.get(p, "")))

            for k in spec.style:
                if k in BASE_PROPS:
                    continue
                self._ensure_prop_row(k)
                self.props_vars[k].set(str(spec.style.get(k, "")))

            fns = self.function_names_provider() or []
            for ev, cb in self.event_cbs.items():
                cb.config(values=[""] + list(fns))
                self.event_vars[ev].set(spec.events.get(ev, ""))

            self.code_editor.set_code(self._widget_code(spec))
        finally:
            self._loading = False

    def sync_from_model(self, spec: WidgetSpec):
        self._loading = True
        try:
            if self.current is not spec:
                self.current = spec
                self.id_lbl.config(text=spec.wid)

            focused = self.focus_get()
            for k, var in self.geom_vars.items():
                ent = self.entries.get("__geom_" + k)
                if focused is ent:
                    continue
                want = str(spec.geometry.get(k, ""))
                if var.get() != want:
                    var.set(want)

            for p, var in self.props_vars.items():
                ent = self.entries.get(p)
                if focused is ent:
                    continue
                if p == "text":
                    want = spec.text
                else:
                    want = str(spec.style.get(p, ""))
                if var.get() != want:
                    var.set(want)

            self.code_editor.set_code(self._widget_code(spec))
        finally:
            self._loading = False

    # ★ обновить список функций в комбобоксах событий (после переименования)
    def refresh_event_values(self):
        fns = self.function_names_provider() or []
        for ev, cb in self.event_cbs.items():
            cb.config(values=[""] + list(fns))

    def _widget_code(self, spec: WidgetSpec) -> str:
        args = _format_widget_args(spec)
        g = spec.geometry
        code = f"{spec.wid} = {spec.kind}({args[2:] if args.startswith(', ') else ''})\n"
        code += (f"{spec.wid}.place(x={g.get('x', 0)}, y={g.get('y', 0)}, "
                 f"width={g.get('w', 100)}, height={g.get('h', 30)})\n")
        for ev, fn in spec.events.items():
            if not fn:
                continue
            if ev == "command":
                code += f"{spec.wid}.config(command=lambda: _call_with_event({fn}))\n"
            else:
                code += f"{spec.wid}.bind('{ev}', lambda e: _call_with_event({fn}, e))\n"
        return code

    # ---------- пользовательский ввод ----------
    def _push_geometry(self):
        if self._loading or not self.current:
            return
        changed = False
        for k, var in self.geom_vars.items():
            v = var.get()
            if v == "":
                continue
            try:
                iv = int(v)
            except ValueError:
                continue
            if self.current.geometry.get(k) != iv:
                self.current.geometry[k] = iv
                changed = True
        if changed:
            self.code_editor.set_code(self._widget_code(self.current))
            if self.on_change:
                self.on_change(self.current, kind="geometry")

    def _push_style(self):
        if self._loading or not self.current:
            return
        changed = False
        for p, var in self.props_vars.items():
            v = var.get()
            if p == "text":
                if self.current.text != v:
                    self.current.text = v
                    changed = True
            else:
                if v == "":
                    if p in self.current.style:
                        self.current.style.pop(p, None)
                        changed = True
                else:
                    if self.current.style.get(p) != v:
                        self.current.style[p] = v
                        changed = True
        if changed:
            self.code_editor.set_code(self._widget_code(self.current))
            if self.on_change:
                self.on_change(self.current, kind="style")

    def _push_events(self):
        if self._loading or not self.current:
            return
        changed = False
        for ev, var in self.event_vars.items():
            v = var.get()
            if v:
                if self.current.events.get(ev) != v:
                    self.current.events[ev] = v
                    changed = True
            else:
                if ev in self.current.events:
                    self.current.events.pop(ev, None)
                    changed = True
        if changed:
            self.code_editor.set_code(self._widget_code(self.current))
            if self.on_change:
                self.on_change(self.current, kind="style")

    def _add_extra_prop(self, event=None):
        p = self.extra_cb.get()
        if not p or p in self.props_vars:
            return
        self._ensure_prop_row(p)
        if self.current:
            self.props_vars[p].set(str(self.current.style.get(p, "")))

    def _ensure_prop_row(self, p: str):
        if p in self.props_vars:
            return
        f = self._inner
        row = f.grid_size()[1]
        lbl = ttk.Label(f, text=p)
        var = tk.StringVar()
        ent = ttk.Entry(f, textvariable=var)
        var.trace_add("write", lambda *_: self._push_style())
        lbl.grid(row=row, column=0, sticky="w", padx=4, pady=1)
        ent.grid(row=row, column=1, sticky="ew", padx=4, pady=1)
        self.props_vars[p] = var
        self.entries[p] = ent

    def _delete_current(self):
        if not self.current:
            return
        w = self.current
        if self.on_change:
            self.on_change(("DELETE", w))
        self.current = None
        self.load(None)

    def _bring_front(self):
        if not self.current:
            return
        if self.on_change:
            self.on_change(("FRONT", self.current))

    def _apply_code(self):
        if not self.current:
            return
        try:
            tree = ast.parse(self.code_editor.get_code())
        except SyntaxError as e:
            messagebox.showerror("Ошибка синтаксиса", str(e))
            return
        for node in tree.body:
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
                call = node.value
                if isinstance(call.func, ast.Name):
                    self.current.kind = call.func.id
                new_style: dict = {}
                text = ""
                for kw in call.keywords:
                    try:
                        val = ast.literal_eval(kw.value)
                    except Exception:
                        continue
                    if kw.arg == "text":
                        text = str(val)
                    else:
                        new_style[kw.arg] = val
                self.current.text = text
                self.current.style.update(new_style)
            if (isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                    and isinstance(node.value.func, ast.Attribute)
                    and node.value.func.attr == "place"):
                for kw in node.value.keywords:
                    try:
                        val = ast.literal_eval(kw.value)
                    except Exception:
                        continue
                    if kw.arg in ("x", "y", "width", "height"):
                        key = {"x": "x", "y": "y", "width": "w", "height": "h"}[kw.arg]
                        self.current.geometry[key] = val
        self.load(self.current)
        if self.on_change:
            self.on_change(self.current, kind="style")


# ══════════════════════════════════════════════════════════════════
#  БАНК ФУНКЦИЙ
# ══════════════════════════════════════════════════════════════════

class FunctionBank(ttk.Frame):
    def __init__(self, master, project: Project):
        super().__init__(master)
        self.project = project
        self.on_rename = None    # ★ callback(old, new)

        left = ttk.Frame(self)
        left.pack(side="left", fill="y", padx=4, pady=4)

        ttk.Label(left, text="Функции").pack(anchor="w")
        self.listbox = tk.Listbox(left, width=28, exportselection=False)
        self.listbox.pack(fill="y", expand=True)
        self.listbox.bind("<<ListboxSelect>>", self._load)
        self.listbox.bind("<Double-Button-1>", self._focus_rename)

        btns = ttk.Frame(left)
        btns.pack(fill="x", pady=4)
        ttk.Button(btns, text="+ Доб.", command=self._add).pack(side="left")
        ttk.Button(btns, text="− Удал.", command=self._del).pack(side="left")
        ttk.Button(btns, text="Импорты", command=self._edit_imports).pack(side="right")

        # ★ Поле переименования
        rename_frame = ttk.LabelFrame(left, text="Имя")
        rename_frame.pack(fill="x", pady=(8, 0))
        self.name_var = tk.StringVar()
        self.name_entry = ttk.Entry(rename_frame, textvariable=self.name_var)
        self.name_entry.pack(fill="x", padx=4, pady=(2, 0))
        self.name_entry.bind("<Return>", lambda e: self._rename())
        ttk.Button(rename_frame, text="Переименовать",
                   command=self._rename).pack(fill="x", padx=4, pady=4)

        right = ttk.Frame(self)
        right.pack(side="right", fill="both", expand=True, padx=4, pady=4)

        self.nb = ttk.Notebook(right)
        self.nb.pack(fill="both", expand=True)

        # ★ редактор функции получает доступ к именам функций проекта
        self.editor = CodeEditor(
            self.nb,
            extra_words_provider=lambda: list(self.project.functions.keys())
        )
        self.nb.add(self.editor, text="Код функции")

        self.meta = tk.Text(self.nb, height=10, font=("Consolas", 10))
        self.nb.add(self.meta, text="Импорты и статистика")

        self._current: str | None = None
        self._refresh()
        self._refresh_meta()

    # ---------- список ----------
    def _refresh(self):
        self.listbox.delete(0, "end")
        for name in self.project.functions:
            self.listbox.insert("end", name)
        if self._current in self.project.functions:
            idx = list(self.project.functions).index(self._current)
            self.listbox.selection_set(idx)
            self.listbox.see(idx)

    def _refresh_meta(self):
        self.meta.delete("1.0", "end")
        self.meta.insert("end", "# Импорты проекта\n")
        for imp in self.project.imports:
            self.meta.insert("end", f"import {imp}\n")
        self.meta.insert("end", "\n# Статистика\n")
        src = self.project.to_code()
        self.meta.insert("end", f"Строк всего: {len(src.splitlines())}\n")
        self.meta.insert("end", f"Виджетов: {len(self.project.widgets)}\n")
        self.meta.insert("end", f"Функций: {len(self.project.functions)}\n")

    def _add(self):
        name = f"func_{len(self.project.functions) + 1}"
        while name in self.project.functions:
            name += "_"
        self.project.functions[name] = "pass"
        self._current = name
        self.name_var.set(name)
        self._refresh()
        self._load(None)

    def _del(self):
        sel = self.listbox.curselection()
        if not sel:
            return
        name = self.listbox.get(sel[0])
        if name in self.project.functions:
            del self.project.functions[name]
        self._current = None
        self._refresh()
        self.editor.set_code("")
        self.name_var.set("")
        self._refresh_meta()
        if self.on_rename:
            try:
                self.on_rename(name, None)
            except Exception:
                pass

    def _load(self, event=None):
        sel = self.listbox.curselection()
        if not sel:
            return
        self._save_current()
        name = self.listbox.get(sel[0])
        self._current = name
        self.name_var.set(name)
        self.editor.set_code(self.project.functions.get(name, ""))

    def _save_current(self):
        if self._current and self._current in self.project.functions:
            self.project.functions[self._current] = self.editor.get_code()

    def save_all(self):
        self._save_current()

    # ---------- переименование ----------
    def _focus_rename(self, event=None):
        self.name_entry.focus_set()
        self.name_entry.select_range(0, "end")
        return "break"

    def _rename(self):
        old = self._current
        new = self.name_var.get().strip()
        if not old or not new:
            return
        if old == new:
            return
        if not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", new):
            messagebox.showerror("Ошибка", "Недопустимое имя функции.")
            self.name_var.set(old)
            return
        if new in self.project.functions:
            messagebox.showerror("Ошибка", "Функция с таким именем уже существует.")
            self.name_var.set(old)
            return

        self._save_current()

        # перестраиваем dict с сохранением порядка
        new_funcs = {}
        for k, v in self.project.functions.items():
            if k == old:
                new_funcs[new] = v
            else:
                new_funcs[k] = v
        self.project.functions = new_funcs

        # обновляем ссылки в событиях всех виджетов
        for w in self.project.widgets:
            for ev, fn in list(w.events.items()):
                if fn == old:
                    w.events[ev] = new

        # мягко обновляем вызовы old( в телах других функций
        pat = re.compile(rf"\b{re.escape(old)}\b")
        for k, body in list(self.project.functions.items()):
            new_body = pat.sub(new, body)
            if new_body != body:
                self.project.functions[k] = new_body

        self._current = new
        self._refresh()
        # перезагрузить редактор (в теле могли поменяться ссылки)
        self.editor.set_code(self.project.functions.get(new, ""))

        if self.on_rename:
            try:
                self.on_rename(old, new)
            except Exception:
                pass

    # ---------- импорты ----------
    def _edit_imports(self):
        win = tk.Toplevel(self)
        win.title("Импорты проекта")
        win.geometry("420x360")
        ttk.Label(win, text="По одному на строку (без 'import')").pack(pady=4)
        t = tk.Text(win, font=("Consolas", 11))
        t.pack(fill="both", expand=True, padx=6, pady=6)
        t.insert("1.0", "\n".join(self.project.imports))

        def save():
            self.project.imports = [
                l.strip() for l in t.get("1.0", "end-1c").splitlines() if l.strip()
            ]
            win.destroy()
            self._refresh_meta()

        ttk.Button(win, text="Сохранить", command=save).pack(pady=6)


# ══════════════════════════════════════════════════════════════════
#  ГЛАВНОЕ ПРИЛОЖЕНИЕ
# ══════════════════════════════════════════════════════════════════

class Application:
    def __init__(self):
        self.tk = tk.Tk()
        self.tk.title("gui_ui — визуальный конструктор Tkinter")
        try:
            self.tk.attributes("-fullscreen", True)
        except tk.TclError:
            self.tk.geometry("1400x860")

        self.tk.bind("<Escape>", lambda e: self.tk.attributes("-fullscreen", False))
        self.tk.bind("<F11>", self._toggle_fullscreen)
        self.tk.bind("<F5>", lambda e: self._run_preview())

        self.project = Project(title="MyApp", geometry="800x600")
        self.project.functions["on_click"] = "print('clicked')"

        self._build_menu()
        self._build_layout()

    def _toggle_fullscreen(self, event=None):
        cur = bool(self.tk.attributes("-fullscreen"))
        self.tk.attributes("-fullscreen", not cur)

    def _build_menu(self):
        m = tk.Menu(self.tk)
        self.tk.config(menu=m)

        fm = tk.Menu(m, tearoff=0)
        fm.add_command(label="Новый проект",        command=self._new)
        fm.add_command(label="Открыть (.json)",     command=self._open_json)
        fm.add_command(label="Открыть (.py)",       command=self._import_py)
        fm.add_separator()
        fm.add_command(label="Сохранить (.json)",   command=self._save_json)
        fm.add_command(label="Экспорт в .py",       command=self._export_py)
        fm.add_separator()
        fm.add_command(label="Выход", command=self.tk.quit)
        m.add_cascade(label="Файл", menu=fm)

        rm = tk.Menu(m, tearoff=0)
        rm.add_command(label="Запустить (F5)", command=self._run_preview)
        rm.add_command(label="Показать код",   command=self._show_code)
        m.add_cascade(label="Запуск", menu=rm)

        vm = tk.Menu(m, tearoff=0)
        vm.add_command(label="Fullscreen (F11)", command=self._toggle_fullscreen)
        m.add_cascade(label="Вид", menu=vm)

        hm = tk.Menu(m, tearoff=0)
        hm.add_command(label="О программе", command=self._about)
        m.add_cascade(label="Справка", menu=hm)

    def _build_layout(self):
        palette = ttk.Frame(self.tk, width=170)
        palette.pack(side="left", fill="y")
        palette.pack_propagate(False)
        ttk.Label(palette, text="Виджеты", font=("", 11, "bold")).pack(pady=6)
        for kind in ("Button", "Label", "Entry", "Text", "Frame", "LabelFrame",
                     "Treeview", "Combobox", "Checkbutton", "Radiobutton",
                     "Listbox", "Scale", "Notebook"):
            ttk.Button(palette, text=kind,
                       command=lambda k=kind: self._add_widget(k)
                       ).pack(fill="x", padx=4, pady=1)

        self.notebook = ttk.Notebook(self.tk)
        self.notebook.pack(side="left", fill="both", expand=True, padx=4, pady=4)

        self.canvas = DesignCanvas(self.notebook, self.project,
                                   on_select=self._on_select,
                                   on_change=self._on_canvas_change)
        self.notebook.add(self.canvas, text="Холст")

        self.bank = FunctionBank(self.notebook, self.project)
        self.bank.on_rename = self._on_function_renamed    # ★
        self.notebook.add(self.bank, text="Банк функций")

        prev = ttk.Frame(self.notebook)
        self.notebook.add(prev, text="Предпросмотр / Код")
        self.code_view = CodeEditor(
            prev,
            extra_words_provider=lambda: list(self.project.functions.keys())
        )
        self.code_view.pack(fill="both", expand=True)
        bar = ttk.Frame(prev)
        bar.pack(fill="x")
        ttk.Button(bar, text="Обновить", command=self._refresh_code_view).pack(side="left")
        ttk.Button(bar, text="Запустить (F5)",
                   command=self._run_preview).pack(side="left")

        right = ttk.Frame(self.tk, width=380)
        right.pack(side="right", fill="y", padx=4, pady=4)
        right.pack_propagate(False)
        self.inspector = Inspector(right)
        self.inspector.pack(fill="both", expand=True)
        self.inspector.on_change = self._on_inspector_change
        self.inspector.function_names_provider = lambda: list(self.project.functions.keys())

        self.canvas.render_all()
        self._refresh_code_view()

    def _add_widget(self, kind: str):
        n = len(self.project.widgets) + 1
        wid = f"{kind.lower()}_{n}"
        while any(w.wid == wid for w in self.project.widgets):
            n += 1
            wid = f"{kind.lower()}_{n}"
        spec = WidgetSpec(wid=wid, kind=kind, parent="root", text=kind)
        self.project.widgets.append(spec)
        self.canvas.render_all()
        widget = self.canvas.live.get(wid)
        if widget:
            self.canvas.selected = spec
            widget.configure(highlightthickness=2,
                             highlightbackground="#ff6600")
            self.inspector.load(spec)
        self._refresh_code_view()

    def _on_select(self, spec):
        self.inspector.load(spec)

    def _on_canvas_change(self, spec, kind: str = "style"):
        if isinstance(spec, tuple):
            tag, w = spec
            if tag == "DELETE":
                self.project.widgets = [x for x in self.project.widgets if x.wid != w.wid]
                self.canvas.render_all()
                self.inspector.load(None)
            elif tag == "FRONT":
                self.project.widgets.remove(w)
                self.project.widgets.append(w)
                self.canvas.render_all()
            self._refresh_code_view()
            return

        if kind == "geometry":
            widget = self.canvas.live.get(spec.wid)
            if widget is not None:
                g = spec.geometry
                s = self.canvas.scale
                try:
                    widget.place(x=int(g["x"] * s), y=int(g["y"] * s),
                                 width=max(1, int(g["w"] * s)),
                                 height=max(1, int(g["h"] * s)))
                except Exception:
                    pass
            else:
                self.canvas.render_all()
        else:
            self.canvas.recreate_widget(spec)

        if self.canvas.selected and self.canvas.selected is spec:
            self.inspector.sync_from_model(spec)

        self._refresh_code_view()

    def _on_inspector_change(self, spec, kind: str = "style"):
        self._on_canvas_change(spec, kind=kind)

    # ★ при переименовании — обновляем подсказки в инспекторе и код
    def _on_function_renamed(self, old: str, new):
        try:
            self.inspector.refresh_event_values()
        except Exception:
            pass
        self._refresh_code_view()

    def _refresh_code_view(self):
        self.bank.save_all()
        code = self.project.to_code()
        self.code_view.set_code(code)

    def _new(self):
        if not messagebox.askyesno("Новый", "Отменить текущий проект?"):
            return
        self.project = Project(title="MyApp", geometry="800x600")
        self.canvas.project = self.project
        self.bank.project = self.project
        self.canvas._sync_size_entry()
        self.canvas._resize_stage()
        self.canvas.render_all()
        self.bank._refresh()
        self.bank._refresh_meta()
        self._refresh_code_view()

    def _save_json(self):
        path = filedialog.asksaveasfilename(defaultextension=".json",
                                             filetypes=[("JSON", "*.json")])
        if not path:
            return
        self.bank.save_all()
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.project.to_json(), f, ensure_ascii=False, indent=2)
        messagebox.showinfo("Сохранено", path)

    def _open_json(self):
        path = filedialog.askopenfilename(filetypes=[("JSON", "*.json")])
        if not path:
            return
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        self.project = Project.from_json(data)
        self.canvas.project = self.project
        self.bank.project = self.project
        self.canvas._sync_size_entry()
        self.canvas._resize_stage()
        self.canvas.render_all()
        self.bank._refresh()
        self.bank._refresh_meta()
        self._refresh_code_view()

    def _import_py(self):
        path = filedialog.askopenfilename(filetypes=[("Python", "*.py")])
        if not path:
            return
        with open(path, encoding="utf-8") as f:
            src = f.read()
        self.project = parse_tkinter_source(src)
        self.canvas.project = self.project
        self.bank.project = self.project
        self.canvas._sync_size_entry()
        self.canvas._resize_stage()
        self.canvas.render_all()
        self.bank._refresh()
        self.bank._refresh_meta()
        self._refresh_code_view()
        messagebox.showinfo(
            "Импорт",
            f"Виджетов: {len(self.project.widgets)}\n"
            f"Функций: {len(self.project.functions)}\n"
            f"Импортов: {len(self.project.imports)}"
        )

    def _export_py(self):
        self.bank.save_all()
        path = filedialog.asksaveasfilename(defaultextension=".py",
                                             filetypes=[("Python", "*.py")])
        if not path:
            return
        code = self.project.to_code()
        with open(path, "w", encoding="utf-8") as f:
            f.write(code)
        messagebox.showinfo(
            "Экспорт",
            f"Файл: {path}\nСтрок: {len(code.splitlines())}"
        )

    def _show_code(self):
        self._refresh_code_view()
        self.notebook.select(2)

    def _run_preview(self):
        self.bank.save_all()
        code = self.project.to_code()
        tmp = tempfile.NamedTemporaryFile("w", suffix=".py",
                                           delete=False, encoding="utf-8")
        try:
            tmp.write(code)
            tmp.close()
            kwargs = {}
            if sys.platform.startswith("win"):
                kwargs["creationflags"] = 0x00000010
            subprocess.Popen([sys.executable, tmp.name], **kwargs)
        except Exception as e:
            messagebox.showerror("Ошибка запуска", str(e))

    def _about(self):
        messagebox.showinfo(
            "О программе",
            "gui_ui 0.1.0\n\n"
            "Визуальный конструктор Tkinter.\n"
            "Без внешних зависимостей.\n\n"
            "F5 — запустить, F11 — fullscreen, Esc — выход.\n"
            "Ctrl+Space — вызвать автодополнение вручную.\n"
            "Ctrl+колесо — зум холста."
        )

    def run(self):
        self.tk.mainloop()


# ══════════════════════════════════════════════════════════════════
#  ТОЧКА ВХОДА
# ══════════════════════════════════════════════════════════════════

def main():
    print("=" * 60)
    print("  Пожалуйста, не закрывайте это консольное окно")
    print("  во время работы со скриптом.")
    print("=" * 60)

    try:
        Application().run()
    except KeyboardInterrupt:
        print("\nПрервано пользователем.")
    except Exception:
        traceback.print_exc()
        try:
            input("Нажмите Enter для выхода...")
        except EOFError:
            pass
        sys.exit(1)


if __name__ == "__main__":
    main()